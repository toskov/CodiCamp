var searchData=
[
  ['max_5fchars_5fin_5fint32_5fstr',['MAX_CHARS_IN_INT32_STR',['../group___global_constants.html#gaddd984842e99ec528fe961c78f50e9ca',1,'Defines.h']]],
  ['max_5fchars_5fin_5fint64_5fstr',['MAX_CHARS_IN_INT64_STR',['../group___global_constants.html#gae587b57ce0d4b87a4c978eed53e7a125',1,'Defines.h']]],
  ['max_5ftoken',['MAX_TOKEN',['../group___global_constants.html#ga1df09ca9a5001c8158b8e68063111c05',1,'Defines.h']]]
];
