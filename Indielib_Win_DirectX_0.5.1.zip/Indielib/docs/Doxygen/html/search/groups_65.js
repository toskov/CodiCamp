var searchData=
[
  ['entity_20objects_20and_20entity_20managers_20_28the_20most_20important_20concept_20of_20indielib_29',['Entity Objects and Entity Managers (the most important concept of IndieLib)',['../group___entity_managers.html',1,'']]]
];
