var searchData=
[
  ['font_20alignment',['Font alignment',['../group___i_n_d___align.html',1,'']]],
  ['filtering_20when_20rendering',['Filtering when rendering',['../group___i_n_d___filter.html',1,'']]]
];
