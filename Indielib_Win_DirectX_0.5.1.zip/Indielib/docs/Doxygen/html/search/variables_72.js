var searchData=
[
  ['revision',['revision',['../struct_indie__version.html#acf742efd27c363cd5b09d3ec2120a2e5',1,'Indie_version']]]
];
